wget http://cs231n.stanford.edu/pretrained_model.h5
