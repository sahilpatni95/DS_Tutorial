# Assignment 2 

## Thanks
Could not have completed the assignments without help from other github users who have open sourced their code for the class.  In particular, much of the code in this assignment is based on repos provided by: 

> 

- [cthorey](https://github.com/cthorey/CS231)

- [OneRaynyDay](https://github.com/OneRaynyDay/CS231n/tree/master/assignment2)

- [martinkersner](https://github.com/martinkersner/cs231n/tree/master/assignment2)

I suggest you check out their repos and give them a star for providing well documented and helpful code!

TODO: Experiment section of the ConvolutionalNetworks.ipynb when I figure out how to get more computing power.
